<!DOCTYPE html>
<!--[if IE 7]><html class="ie ie7 ltie8 ltie9" lang="en-US" xmlns:fb="https://www.facebook.com/2008/fbml" xmlns:addthis="https://www.addthis.com/help/api-spec" ><![endif]-->
<!--[if IE 8]><html class="ie ie8 ltie9" lang="en-US" xmlns:fb="https://www.facebook.com/2008/fbml" xmlns:addthis="https://www.addthis.com/help/api-spec" ><![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US" xmlns:fb="https://www.facebook.com/2008/fbml" xmlns:addthis="https://www.addthis.com/help/api-spec" >
<!--<![endif]-->

<head>
	<meta charset="UTF-8" />    
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="pingback" href="http://kodeforest.com/xmlrpc.php" />	
	
	<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title>Nothing found for  Html Kickoff Inc Image Php</title>

<!-- All in One SEO Pack 2.12.1 by Michael Torbert of Semper Fi Web Design[903,976] -->
<meta name="robots" content="noindex,follow" />

<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="KodeForest Design &amp; Development Company &raquo; Feed" href="https://kodeforest.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="KodeForest Design &amp; Development Company &raquo; Comments Feed" href="https://kodeforest.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/kodeforest.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.13"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://kodeforest.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='style-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/style.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-typo-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/themetypo.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-bootstrap-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/bootstrap.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-color-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/color.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-custom-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/style-custom.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/font-awesome/css/font-awesome.min.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='kodeproperty-search-script-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/css/search.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='kodeproperty-chosen-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/backend_assets/js/kode-chosen/chosen.min.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-component-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/dl-menu/component.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-woocommerce-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/css/woocommerce.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-svg-icon-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/svg-icon/svg-icon.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-shortcode-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/shortcode.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-widget-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/widget.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-responsive-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/responsive.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-navi-default-Open-Sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic&#038;subset=greek%2Ccyrillic-ext%2Ccyrillic%2Clatin%2Clatin-ext%2Cvietnamese%2Cgreek-ext&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h1-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h2-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h3-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h4-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h5-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-h6-Varela-Round-css'  href='https://fonts.googleapis.com/css?family=Varela+Round%3Aregular&#038;subset=latin&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-body-Open-Sans-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic&#038;subset=greek%2Ccyrillic-ext%2Ccyrillic%2Clatin%2Clatin-ext%2Cvietnamese%2Cgreek-ext&#038;ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='kodeproperty-bootstrap-slider-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/css/bootstrap-slider.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='bx-slider-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/bxslider/bxslider.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/flexslider/flexslider.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='style-prettyphoto-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/css/prettyphoto.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='nivo-slider-css'  href='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/nivo-slider/nivo-slider.css?ver=4.7.13' type='text/css' media='all' />
<link rel='stylesheet' id='ms-main-css'  href='http://kodeforest.com/wp-content/plugins/masterslider/public/assets/css/masterslider.main.css?ver=3.2.14' type='text/css' media='all' />
<link rel='stylesheet' id='ms-custom-css'  href='http://kodeforest.com/wp-content/uploads/masterslider/custom.css?ver=7.9' type='text/css' media='all' />
<link rel='stylesheet' id='addthis_all_pages-css'  href='http://kodeforest.com/wp-content/plugins/addthis/frontend/build/addthis_wordpress_public.min.css?ver=4.7.13' type='text/css' media='all' />
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_login_object = {"loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/newsletter.js?ver=4.7.13'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_login_object = {"ajaxurl":"https:\/\/kodeforest.com\/wp-admin\/admin-ajax.php","redirecturl":"https:\/\/kodeforest.com","loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/ajax-login-script.js?ver=4.7.13'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_signup_object = {"ajaxurl":"https:\/\/kodeforest.com\/wp-admin\/admin-ajax.php","redirecturl":"https:\/\/kodeforest.com","loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/ajax-signup-script.js?ver=4.7.13'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/backend_assets/js/kode-chosen/chosen.jquery.min.js?ver=4.7.13'></script>
<link rel='https://api.w.org/' href='https://kodeforest.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kodeforest.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://kodeforest.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.7.13" />
<script>var ms_grabbing_curosr='http://kodeforest.com/wp-content/plugins/masterslider/public/assets/css/common/grabbing.cur',ms_grab_curosr='http://kodeforest.com/wp-content/plugins/masterslider/public/assets/css/common/grab.cur';</script>
<meta name="generator" content="MasterSlider 3.2.14 - Responsive Touch Image Slider" />
<script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		if (window.wfLogHumanRan) { return; }
		window.wfLogHumanRan = true;
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('//kodeforest.com/?wordfence_lh=1&hid=187A0F17EBBD39DA06DEB7F342D20F6C');
</script><link rel="shortcut icon" href="https://kodeforest.com/wp-content/uploads/2016/10/logo-1.png" type="image/x-icon" />		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<script data-cfasync="false" type="text/javascript">if (window.addthis_product === undefined) { window.addthis_product = "wpp"; } if (window.wp_product_version === undefined) { window.wp_product_version = "wpp-6.2.3"; } if (window.wp_blog_version === undefined) { window.wp_blog_version = "4.7.13"; } if (window.addthis_share === undefined) { window.addthis_share = {}; } if (window.addthis_config === undefined) { window.addthis_config = {"data_track_clickback":true,"ignore_server_config":true,"ui_atversion":300}; } if (window.addthis_layers === undefined) { window.addthis_layers = {}; } if (window.addthis_layers_tools === undefined) { window.addthis_layers_tools = [{"sharetoolbox":{"numPreferredServices":5,"counts":"one","size":"32px","style":"fixed","shareCountThreshold":0,"elements":".addthis_inline_share_toolbox_above,.at-above-post-homepage,.at-above-post-arch-page,.at-above-post-cat-page,.at-above-post,.at-above-post-page"}}]; } else { window.addthis_layers_tools.push({"sharetoolbox":{"numPreferredServices":5,"counts":"one","size":"32px","style":"fixed","shareCountThreshold":0,"elements":".addthis_inline_share_toolbox_above,.at-above-post-homepage,.at-above-post-arch-page,.at-above-post-cat-page,.at-above-post,.at-above-post-page"}});  } if (window.addthis_plugin_info === undefined) { window.addthis_plugin_info = {"info_status":"enabled","cms_name":"WordPress","plugin_name":"Share Buttons by AddThis","plugin_version":"6.2.3","plugin_mode":"WordPress","anonymous_profile_id":"wp-d5af0c278270cbaea3d57a6735eb9eb4","page_info":{"template":false,"post_type":""},"sharing_enabled_on_post_via_metabox":false}; } 
                    (function() {
                      var first_load_interval_id = setInterval(function () {
                        if (typeof window.addthis !== 'undefined') {
                          window.clearInterval(first_load_interval_id);
                          if (typeof window.addthis_layers !== 'undefined' && Object.getOwnPropertyNames(window.addthis_layers).length > 0) {
                            window.addthis.layers(window.addthis_layers);
                          }
                          if (Array.isArray(window.addthis_layers_tools)) {
                            for (i = 0; i < window.addthis_layers_tools.length; i++) {
                              window.addthis.layers(window.addthis_layers_tools[i]);
                            }
                          }
                        }
                     },1000)
                    }());
                </script> <script data-cfasync="false" type="text/javascript" src="https://s7.addthis.com/js/300/addthis_widget.js#pubid=wp-d5af0c278270cbaea3d57a6735eb9eb4" async="async"></script></head>
<body class="error404 _masterslider _msp_version_3.2.14" id="home">
<div class="body-wrapper" data-home="https://kodeforest.com/">
				
				<!--HEADER Start-->  
				<header class="kode-navigation-sticky">
					
					<!--TOP NAVI WRAPER START-->
					<div class="top_navi_wraper">
						<div class="top_navigation_row">
							<div class="container-fluid">
								<div class="top_navi_cols">
									<div class="kode_top_log">
										<h1>
										<a class="kode-logo logo" href="https://kodeforest.com/" >
											<img src="https://kodeforest.com/wp-content/uploads/2016/10/logo.png" alt="" width="87" height="64" />						
										</a>
										</h1>
									</div>
									<div class="kode_top_navigation">
										<div class="kode-navigation-wrapper"><nav class="navigation"><div class="menu-home-container"><ul id="menu-home" class="menu"><li id="menu-item-72" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-72"><a href="https://kodeforest.com/">Home</a></li>
<li id="menu-item-212" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212"><a href="https://kodeforest.com/blog/">Blog</a></li>
<li id="menu-item-74" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-74"><a target="_blank" href="http://kodeforest.com/support">Support</a></li>
<li id="menu-item-76" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76"><a target="_blank" href="https://themeforest.net/user/kodeforest">Our Profile</a></li>
<li id="menu-item-87" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-87"><a href="https://kodeforest.com/contact-us/">Contact Us</a></li>
</ul></div></nav><div class="clear"></div></div>	
									</div>
									<div class="kode-responsive-navigation dl-menuwrapper" id="kode-responsive-navigation" ><button class="dl-trigger">Open Menu</button><ul id="menu-home-1" class="dl-menu kode-main-mobile-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-72"><a href="https://kodeforest.com/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-212"><a href="https://kodeforest.com/blog/">Blog</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-74"><a target="_blank" href="http://kodeforest.com/support">Support</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-76"><a target="_blank" href="https://themeforest.net/user/kodeforest">Our Profile</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-87"><a href="https://kodeforest.com/contact-us/">Contact Us</a></li>
</ul></div>								</div>
							</div>
						</div>
					
						
					</div>
					<!--TOP NAVI WRAPER END-->
				</header>
				<!--HEADER END-->
					<!--KODE SAB BANNER START
		<div   class="kode_sab_banner banner_2 banner_3 header-style-1">
			<img src="http://kodeforest.com/wp-content/themes/kodeforest/images/images/banner3.jpg" alt="" />
			<div class="kode_banner_text text_2  text_3 wow fadeInRight">
				<h2>404 Error Page</h2>
									<ul id="breadcrumbs" class="kode-breadcrumb breadcrumb"><li class="item-home"><a class="bread-link bread-home" href="https://kodeforest.com" title="Homepage">Homepage</a></li><li>Error 404</li></ul>							</div>
		</div>
		<!--KODE SAB BANNER END-->
		
		
		<div class="content-wrapper">
	
		<!--Content Wrap Start-->
    <div class="kode_wrapper_bg_image">
	<div class="kode_404_wraper">
		<div class="container">
			<div class="kode_404_text">
				<h2>4<span>0</span>4</h2>
				<h5>The page you are found does’nt exist ! Move back to our home page ...</h5>
				<form>
					<input type="text" placeholder="Enter Your Email" required>
					<button>Go<i class="fa fa-arrow-right"></i></button>
				</form>
				<p>copyright 2016 © <a href="#">kodeforest.com</a></p>
			</div>
			<ul class="kode_404_social">
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
				<li><a href="#"><i class="fa fa-twitter"></i></a></li>
				<li><a href="#"><i class="fa fa-rss"></i></a></li>
				<li><a href="#"><i class="fa fa-facebook"></i></a></li>
			</ul>
		</div>
	</div>
</div>
	</div>
    <!--Twitter Wrap End-->
		
<script type='text/javascript' src='http://kodeforest.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.6.1'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/search.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/dl-menu/modernizr.custom.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/dl-menu/jquery.dlmenu.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/jquery/ui/slider.min.js?ver=1.11.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"https:\/\/kodeforest.com\/wp-admin\/admin-ajax.php","nonce":"f94532a518"};
/* ]]> */
</script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/bootstrap.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/bootstrap-slider.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/jquery.accordion.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/filterable.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/jquery-downcount.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/ajax-upload.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/bxslider/jquery.bxslider.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/waypoints-min.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/bg-moving.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/flexslider/jquery.flexslider.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/jquery.prettyphoto.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/default/js/pp.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/nivo-slider/jquery.nivo.slider.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/framework/include/frontend_assets/jquery.easing.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-content/themes/kodeforest/js/functions.js?ver=1.0'></script>
<script type='text/javascript' src='http://kodeforest.com/wp-includes/js/wp-embed.min.js?ver=4.7.13'></script>
		
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-57331671-6', 'auto');
  ga('send', 'pageview');

</script>
</div>
<!--Kode Wrapper End-->	


</body>
</html>